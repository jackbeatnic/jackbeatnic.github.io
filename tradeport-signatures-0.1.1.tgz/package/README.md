# @tradeport/signatures

A TypeScript library for normalizing blockchain signatures to a standard format across multiple chains including Sui, Aptos, Movement, Supra, and Iota to be used for passing in the correct data to TradePort's auth service to create a JWT

## Features

- 🔐 Unified interface for normalizing wallet signatures across different blockchains
- 🎯 Type-safe TypeScript implementation
- 🏗️ Clean, extensible architecture using the Strategy Pattern
- ✨ Support for Sui (with zkLogin), Aptos, Movement, and Supra
- 🔌 Easy integration with any frontend application or SDK
- 📦 Simple API: `new SignatureNormalizer(blockchain).normalize(...)`

## Installation

```bash
npm install @tradeport/signatures
# or
yarn add @tradeport/signatures
# or
pnpm add @tradeport/signatures
```

## Usage

### Basic Usage

```typescript
import { SignatureNormalizer } from "@tradeport/signatures";

// Create a normalizer for your blockchain
const normalizer = new SignatureNormalizer("sui");

// Normalize the signed message to a standard format
const signedMessageData = normalizer.normalize(
  signedMessage,
  walletData,
  originalMessage
);

console.log(signedMessageData);
// {
//   signature: "0x...",
//   message: "0x...",
//   publicKey: "0x...",
//   jwt?: "..." // Optional, for zkLogin or special cases
// }
```

### Using Chain-Specific Normalizers (Advanced)

```typescript
import { SuiSignatureNormalizer } from "@tradeport/signatures";

const suiNormalizer = new SuiSignatureNormalizer();
const result = suiNormalizer.normalize(signedMessage, walletData);
```

### Type Definitions

```typescript
import type {
  Blockchain,
  WalletData,
  SignedMessageData,
} from "@tradeport/signatures";

const walletData: WalletData = {
  walletAddress: "0x...",
  publicKey: "0x...",
  walletName: "Sui Wallet",
};
```

## Supported Blockchains

| Blockchain | Identifier   | Special Features                          |
| ---------- | ------------ | ----------------------------------------- |
| Sui        | `'sui'`      | zkLogin support, wallet-specific handling |
| Aptos      | `'aptos'`    | Extensible for custom wallet formats      |
| Movement   | `'movement'` | Extensible for custom wallet formats      |
| Supra      | `'supra'`    | Extensible for custom wallet formats      |

## Architecture

This library uses the **Strategy Pattern** for clean, maintainable code:

- **`SignatureNormalizer`** - Main class that accepts blockchain type in constructor
- **`BaseSignatureNormalizer`** - Abstract base class defining the interface
- **Chain-specific normalizers** - Internal implementations for each blockchain

### Standardized Output

All normalizers return a consistent `SignedMessageData` format:

```typescript
interface SignedMessageData {
  signature: string; // The signature in appropriate format
  message: string; // The message (usually hex-encoded)
  publicKey: string; // The public key of the signer
  jwt?: string; // Optional JWT (for zkLogin or other special cases)
}
```

## API Reference

### SignatureNormalizer

```typescript
constructor(blockchain: Blockchain)
```

Creates a new signature normalizer for the specified blockchain.

```typescript
normalize(
  signedMessage: any,
  walletData: WalletData,
  originalMessage?: string
): SignedMessageData
```

Normalizes the signed message to a standardized format.

## Extending for Custom Chains

To add support for a new blockchain:

1. Create a new normalizer extending `BaseSignatureNormalizer`
2. Implement the `normalize` method
3. Add your blockchain to the `Blockchain` type
4. Register it in the `SignatureNormalizer` constructor

Example:

```typescript
import {
  BaseSignatureNormalizer,
  SignedMessageData,
  WalletData,
} from "@tradeport/signatures";

export class MyChainSignatureNormalizer extends BaseSignatureNormalizer {
  normalize(
    signedMessage: any,
    walletData: WalletData,
    originalMessage?: string
  ): SignedMessageData {
    // Your custom logic here
    return {
      signature: processedSignature,
      message: this.stringToHex(message),
      publicKey: walletData.publicKey,
    };
  }
}
```

## Development

```bash
# Install dependencies
pnpm install

# Build the library
pnpm build

# Run linting
pnpm lint

# Fix linting issues
pnpm lint:fix

# Run tests
pnpm test
```

## License

MIT

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
